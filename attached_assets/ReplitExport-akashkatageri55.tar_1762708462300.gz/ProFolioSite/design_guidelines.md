# Design Guidelines: Akash Katageri Portfolio Website

## Design Approach

**Reference-Based Approach**: Drawing inspiration from Linear (typography precision), Stripe (professional restraint), and modern developer portfolios with glassmorphism effects. Focus on creating a sophisticated, tech-forward aesthetic that reflects cybersecurity expertise while maintaining approachability.

**Core Principles**:
- Professional credibility through clean, modern design
- Visual interest through subtle animations and glassmorphism
- Clear information hierarchy emphasizing skills and projects
- Dark-first design with seamless light mode

---

## Typography System

**Font Families** (via Google Fonts CDN):
- **Headings**: Inter (600, 700, 800 weights)
- **Body**: Inter (400, 500 weights)
- **Accent/Code**: JetBrains Mono (400, 500 weights) - for tech elements

**Hierarchy**:
- **Hero Name**: text-6xl md:text-7xl lg:text-8xl, font-bold, tracking-tight
- **Section Headings**: text-4xl md:text-5xl, font-bold, tracking-tight
- **Subsection Headings**: text-2xl md:text-3xl, font-semibold
- **Card Titles**: text-xl md:text-2xl, font-semibold
- **Body Text**: text-base md:text-lg, font-normal, leading-relaxed
- **Small Text/Labels**: text-sm, font-medium, tracking-wide, uppercase

---

## Layout System

**Spacing Primitives** (Tailwind units):
- **Micro spacing**: 2, 4 units (gaps, padding within components)
- **Component spacing**: 6, 8, 12 units (internal component structure)
- **Section spacing**: 16, 20, 24, 32 units (vertical rhythm between sections)

**Container Strategy**:
- Full-width sections with max-w-7xl inner containers
- Content sections: max-w-6xl for optimal reading
- Text-heavy areas: max-w-4xl

**Grid Systems**:
- Projects: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 with gap-6 md:gap-8
- Skills: grid-cols-2 md:grid-cols-3 lg:grid-cols-4 with gap-4 md:gap-6
- Certifications: grid-cols-1 md:grid-cols-2 with gap-8

---

## Component Library

### Navigation
- Sticky/fixed header with backdrop-blur effect
- Logo/name on left, navigation links center/right
- Theme toggle (moon/sun icon) in top right
- Mobile: Hamburger menu with slide-in drawer
- Height: h-16 md:h-20

### Hero Section
**Layout**: Full viewport (min-h-screen), centered content with animated gradient background
**Content Structure**:
- Animated greeting text (small, accent color)
- Large name display with gradient text effect
- Professional tagline/role description
- Two-button CTA group (primary + secondary with glass effect)
- Scroll indicator at bottom

**No hero image** - instead use animated gradient mesh background or particle system for visual interest

### About Section
- Two-column layout (lg:grid-cols-2)
- Left: Professional photo placeholder with border gradient effect
- Right: Bio text, key highlights in bullet points
- Skills grid below with icon + label cards

### Projects Showcase
- Filter tabs at top (All, Frontend, Backend, Cybersecurity, etc.)
- Card design with glassmorphism effect (backdrop-blur, subtle border, shadow)
- Each card contains:
  - Project image/thumbnail placeholder with overlay gradient
  - Title and brief description
  - Tech stack badges (pill-shaped, small text)
  - Two action buttons: "Live Demo" + "GitHub" (icon + text)
- Hover state: Slight lift (translate-y), increased shadow

### Skills Section
- Category groupings (Frontend, Backend, Cybersecurity, Tools)
- Icon + label cards with subtle hover animations
- Optional: Circular progress indicators for proficiency levels
- Icons via Heroicons or Font Awesome (CDN)

### Certifications Section
- Large card featuring Cisco certificate with:
  - Certificate image/icon
  - Title: "Introduction to Cybersecurity"
  - Issuing organization: Cisco Networking Academy
  - Date and credential info
  - "View Certificate" button
- Space for additional certifications in grid format

### Contact Section
- Two-column layout (lg:grid-cols-2)
- Left: Contact form (name, email, message) with glass card styling
- Right: Contact info, social links (GitHub, LinkedIn, Twitter placeholders)
- Form inputs with subtle border, focus states with accent color glow
- Submit button with loading state animation

### Footer
- Three-column layout (md:grid-cols-3)
- Left: Name/logo + tagline
- Center: Quick links (About, Projects, Contact)
- Right: Social media icons
- Copyright notice centered below
- Vertical spacing: py-12 md:py-16

---

## Visual Treatment

**Glassmorphism Cards**:
- backdrop-blur-md or backdrop-blur-lg
- Semi-transparent background
- Subtle border (1px, low opacity white/dark)
- Soft shadow for depth

**Gradients**:
- Accent gradients for headings, buttons, borders
- Background gradients (subtle, dark → darker variations)
- Use sparingly for impact

**Borders & Dividers**:
- Rounded corners: rounded-lg (8px), rounded-xl (12px), rounded-2xl (16px)
- Section dividers: Thin, gradient horizontal lines

---

## Animations

**Scroll Animations** (Framer Motion):
- Fade-in + slide-up on scroll into view
- Stagger children animations for lists/grids
- Duration: 0.5-0.8s, ease-out timing

**Micro-interactions**:
- Button hover: Slight scale (1.02-1.05) + brightness increase
- Card hover: Lift effect (translateY -4px to -8px)
- Link hover: Underline slide-in animation
- Theme toggle: Smooth rotation + moon/sun transition

**Page Load**:
- Hero content: Staggered fade-in (name → tagline → buttons)
- No excessive animations - keep professional and smooth

---

## Images

### Certificate Display
- **Location**: Certifications section
- **Description**: Display the provided Cisco Cybersecurity certificate image in a prominent card with subtle shadow and border treatment
- **Styling**: Rounded corners, slight elevation, clickable to expand/view full size

### Project Thumbnails (Placeholders)
- **Location**: Project cards
- **Description**: Abstract tech-themed gradients or geometric patterns as placeholders
- **Aspect Ratio**: 16:9
- **Treatment**: Overlay gradient on hover, slight zoom animation

### Professional Photo Placeholder
- **Location**: About section
- **Description**: Circular or rounded rectangle placeholder for professional headshot
- **Size**: 300x300px to 400x400px
- **Treatment**: Gradient border ring, subtle shadow

**No large hero background image** - use animated gradient/particle effects instead for modern, tech-forward aesthetic

---

## Responsive Behavior

- **Mobile (< 768px)**: Single column, stacked sections, hamburger menu
- **Tablet (768px - 1024px)**: Two-column grids, refined spacing
- **Desktop (> 1024px)**: Full multi-column layouts, enhanced animations

**Critical**: All interactive elements must have touch-friendly sizes (min 44px) on mobile

---

## Accessibility

- Semantic HTML throughout (nav, main, section, article, footer)
- ARIA labels for icon-only buttons
- Keyboard navigation support for all interactive elements
- Focus visible states with clear outline/ring styling
- Color contrast meets WCAG AA standards
- Theme toggle accessible via keyboard and screen readers